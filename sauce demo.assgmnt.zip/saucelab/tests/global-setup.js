// global-setup.js
import { chromium } from "@playwright/test";
import dotenv from "dotenv";
import path from "path";

dotenv.config({ path: path.resolve(__dirname, ".env") });

async function globalSetup() {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  // Go to login page
  await page.goto(process.env.BASE_URL);

  // Perform login
  await page.fill("#user-name", process.env.USERNAME_STANDARD);
  await page.fill("#password", process.env.PASSWORD);
  await page.click("#login-button");

  // Wait until login is successful
  await page.waitForURL(/inventory/);

  // Save storage state (cookies + localStorage)
  await page.context().storageState({ path: "storageState.json" });

  await browser.close();
}

export default globalSetup;
