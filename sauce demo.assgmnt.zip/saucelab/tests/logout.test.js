import { test, expect } from "@playwright/test";
import { MenuPage } from "../pages/menuPage";

// logout.test.js
test("User can reset app state and logout", async ({ page }) => {
  const menuPage = new MenuPage(page);

  await page.goto("/inventory.html");

  // Reset + logout
  await menuPage.resetAppState();
  await menuPage.openMenu();
  await page.locator("#logout_sidebar_link").click();

  // ✅ Verify redirected back to login screen
  await expect(page).toHaveURL(process.env.BASE_URL);
  await expect(page.locator('[data-test="username"]')).toBeVisible();
  await expect(page.locator('[data-test="password"]')).toBeVisible();
});
