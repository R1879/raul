// tests/login.spec.js
import { test, expect } from "@playwright/test";
import { MenuPage } from "../pages/menuPage";
import { LoginPage } from "../pages/loginPage";

test.beforeEach(async ({ page }) => {
  // ✅ Handle dialogs globally
  page.on("dialog", async (dialog) => {
    console.warn(`⚠️ Alert detected: ${dialog.message()}`);
    await dialog.dismiss(); // safer than accept
  });
});

test.describe("Login & Session Handling", () => {
  test("User session is restored and inventory is accessible", async ({
    page,
  }) => {
    await page.goto("/inventory.html");

    // ✅ Verify session restored
    await expect(page).toHaveURL(/inventory/);
    await expect(page.locator(".inventory_list")).toBeVisible();
  });

  test("User can reset app state and close menu", async ({ page }) => {
    const menuPage = new MenuPage(page);

    await page.goto("/inventory.html");

    // ✅ Reset state (menu opens + reset + closes)
    await menuPage.resetAppState();

    // ✅ Verify menu is closed
    await expect(menuPage.resetAppStateLink).toBeHidden();
  });

  test("Locked out user cannot log in", async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.goto();
    await loginPage.login("locked_out_user", process.env.PASSWORD);

    // ✅ Verify correct error message is displayed
    const errorMessage = page.locator('[data-test="error"]');
    await expect(errorMessage).toHaveText(
      "Epic sadface: Sorry, this user has been locked out."
    );
  });
});
