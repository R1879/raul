import { test } from "@playwright/test";
import { InventoryPage } from "../pages/inventoryPage";
import { CartPage } from "../pages/cartPage";
import { CheckoutPage } from "../pages/checkoutPage";

test("User can add items and checkout", async ({ page }) => {
  const inventoryPage = new InventoryPage(page);
  const cartPage = new CartPage(page);
  const checkoutPage = new CheckoutPage(page);

  await page.goto("/inventory.html");

  // Add items
  await inventoryPage.addItemsToCart([
    "sauce-labs-backpack",
    "sauce-labs-bike-light",
    "sauce-labs-bolt-t-shirt",
  ]);

  // Checkout
  await inventoryPage.goToCart();
  await cartPage.proceedToCheckout();
  await checkoutPage.fillCheckoutInfo("John", "Doe", "12345");

  // Verify
  await checkoutPage.verifyItem("Sauce Labs Backpack");
  await checkoutPage.verifyItem("Sauce Labs Bike Light");
  await checkoutPage.verifyItem("Sauce Labs Bolt T-Shirt");
  await checkoutPage.verifyCalculatedTotal("Total: $65.97");
});
