import { test } from "@playwright/test";
import { InventoryPage } from "../pages/inventoryPage";
import { CartPage } from "../pages/cartPage";
import { CheckoutPage } from "../pages/checkoutPage";
import { MenuPage } from "../pages/menuPage";

test.describe("E2E Purchase Journey", () => {
  test("Standard User flow", async ({ page }) => {
    const inventoryPage = new InventoryPage(page);
    const cartPage = new CartPage(page);
    const checkoutPage = new CheckoutPage(page);
    const menuPage = new MenuPage(page);

    // Login
    await page.goto("/");
    await page.fill('[data-test="username"]', process.env.USERNAME_STANDARD);
    await page.fill('[data-test="password"]', process.env.PASSWORD);
    await page.click('[data-test="login-button"]');

    // Reset app
    await menuPage.resetAppState();

    // Add 3 items
    await inventoryPage.addFirstNItems(3);
    await inventoryPage.goToCart();

    // Checkout
    await cartPage.proceedToCheckout();
    await checkoutPage.fillCheckoutInfo("John", "Doe", "12345");
    await checkoutPage.verifyCalculatedTotal();
    await checkoutPage.finishPurchase();

    // Reset & Logout
    await menuPage.resetAppState();
    await menuPage.logout();
  });

  test("Glitch User flow", async ({ page }) => {
    const inventoryPage = new InventoryPage(page);
    const cartPage = new CartPage(page);
    const checkoutPage = new CheckoutPage(page);
    const menuPage = new MenuPage(page);

    // Login
    await page.goto("/");
    await page.fill('[data-test="username"]', process.env.USERNAME_GLITCH);
    await page.fill('[data-test="password"]', process.env.PASSWORD);
    await page.click('[data-test="login-button"]');

    // Reset app
    await menuPage.resetAppState();

    // Sort Z → A and add first product
    await inventoryPage.sortBy("za");
    await inventoryPage.addFirstNItems(1);
    await inventoryPage.goToCart();

    // Checkout
    await cartPage.proceedToCheckout();
    await checkoutPage.fillCheckoutInfo("Jane", "Smith", "67890");
    await checkoutPage.verifyCalculatedTotal();
    await checkoutPage.finishPurchase();

    // Reset & Logout
    await menuPage.resetAppState();
    await menuPage.logout();
  });
});
