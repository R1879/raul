// @ts-check
import { defineConfig, devices } from "@playwright/test";
import dotenv from "dotenv";
import path from "path";

// Load environment variables from .env
dotenv.config({ path: path.resolve(__dirname, ".env") });

/**
 * @see https://playwright.dev/docs/test-configuration
 */
export default defineConfig({
  testDir: "./tests",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: 1,
  reporter: [
    ["line"], // keep console output
    ["allure-playwright"], // add allure reporting
  ],

  // ✅ Run global setup to log in once & save state
  globalSetup: "./tests/global-setup.js",

  use: {
    baseURL: process.env.BASE_URL,
    storageState: "storageState.json",
    headless: false,

    // ✅ Disable fixed viewport so browser can maximize
    viewport: null,

    launchOptions: {
      args: ["--start-maximized"], // ✅ start maximized
    },

    trace: "on-first-retry",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },

  projects: [
    {
      name: "chromium",
      use: {
        // ✅ no devices["Desktop Chrome"] here
        channel: "chrome", // run real Chrome
      },
    },
    // Uncomment if you want more browsers
    // {
    //   name: "firefox",
    //   use: { ...devices["Desktop Firefox"] },
    // },
    // {
    //   name: "webkit",
    //   use: { ...devices["Desktop Safari"] },
    // },
  ],

  // Optional: Run your dev server before tests
  // webServer: {
  //   command: "npm run start",
  //   url: process.env.BASE_URL,
  //   reuseExistingServer: !process.env.CI,
  // },
});
