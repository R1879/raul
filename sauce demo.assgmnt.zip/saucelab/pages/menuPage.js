export class MenuPage {
  constructor(page) {
    this.page = page;
    this.hamburgerButton = page.locator("#react-burger-menu-btn");
    this.resetAppStateLink = page.locator("#reset_sidebar_link");
    this.logoutLink = page.locator("#logout_sidebar_link");
    this.closeMenuButton = page.locator("#react-burger-cross-btn");
  }

  async openMenu() {
    await this.hamburgerButton.click();
    await this.resetAppStateLink.waitFor({ state: "visible" });
  }

  async resetAppState() {
    await this.openMenu();
    await this.resetAppStateLink.click();
    await this.closeMenuButton.click();
  }

  async logout() {
    await this.openMenu();
    await this.logoutLink.click();
  }
}
