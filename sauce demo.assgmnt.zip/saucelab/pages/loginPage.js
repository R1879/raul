// pages/loginPage.js
import { expect } from "@playwright/test";

export class LoginPage {
  constructor(page) {
    this.page = page;
    this.usernameInput = page.locator("#user-name");
    this.passwordInput = page.locator("#password");
    this.loginButton = page.locator("#login-button");
    this.errorMessage = page.locator('[data-test="error"]');
    this.inventoryContainer = page.locator(".inventory_list"); // indicates successful login
    this.defaultTimeout = 5000;
  }

  async goto() {
    await this.page.goto(process.env.BASE_URL); // BASE_URL from .env
  }

  async login(
    username = process.env.USERNAME_STANDARD,
    password = process.env.PASSWORD
  ) {
    await this.usernameInput.waitFor({
      state: "visible",
      timeout: this.defaultTimeout,
    });
    await this.usernameInput.fill(username);

    await this.passwordInput.waitFor({
      state: "visible",
      timeout: this.defaultTimeout,
    });
    await this.passwordInput.fill(password);

    await this.loginButton.click();
  }

  async assertOnLoginPage() {
    await expect(this.usernameInput).toBeVisible({
      timeout: this.defaultTimeout,
    });
    await expect(this.passwordInput).toBeVisible({
      timeout: this.defaultTimeout,
    });
    await expect(this.loginButton).toBeVisible({
      timeout: this.defaultTimeout,
    });
  }

  async assertErrorMessage(expectedMessage) {
    await expect(this.errorMessage).toHaveText(expectedMessage, {
      timeout: this.defaultTimeout,
    });
  }

  async assertLoginSuccessful() {
    await expect(this.inventoryContainer).toBeVisible({
      timeout: this.defaultTimeout,
    });
  }
}
