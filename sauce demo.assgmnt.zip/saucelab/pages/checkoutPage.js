import { expect } from "@playwright/test";

export class CheckoutPage {
  constructor(page) {
    this.page = page;
    this.firstName = page.locator('[data-test="firstName"]');
    this.lastName = page.locator('[data-test="lastName"]');
    this.postalCode = page.locator('[data-test="postalCode"]');
    this.continueButton = page.locator('[data-test="continue"]');
    this.finishButton = page.locator('[data-test="finish"]');
    this.completeHeader = page.locator(".complete-header");
    this.summaryTotal = page.locator(".summary_total_label");
  }

  async fillCheckoutInfo(firstName, lastName, postalCode) {
    await this.firstName.fill(firstName);
    await this.lastName.fill(lastName);
    await this.postalCode.fill(postalCode);
    await this.continueButton.click();
  }

  async verifyItem(name) {
    await expect(
      this.page.locator(".inventory_item_name", { hasText: name })
    ).toBeVisible();
  }

  // checkoutPage.js
  async verifyCalculatedTotal() {
    const itemPrices = await this.page
      .locator(".inventory_item_price")
      .allTextContents();
    const numericPrices = itemPrices.map((p) => parseFloat(p.replace("$", "")));
    const itemTotal = numericPrices.reduce((a, b) => a + b, 0);

    const taxText = await this.page.locator(".summary_tax_label").innerText();
    const tax = parseFloat(taxText.replace("Tax: $", ""));

    const expectedTotal = (itemTotal + tax).toFixed(2);
    await expect(this.summaryTotal).toContainText(`Total: $${expectedTotal}`);
  }

  async finishPurchase() {
    await this.finishButton.click();
    await expect(this.completeHeader).toContainText(
      "Thank you for your order!"
    );
  }
}
