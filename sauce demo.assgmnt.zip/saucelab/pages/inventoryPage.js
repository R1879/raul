export class InventoryPage {
  constructor(page) {
    this.page = page;
    this.cartBadge = page.locator(".shopping_cart_badge");
    this.cartLink = page.locator(".shopping_cart_link");
    this.sortDropdown = page.locator('[data-test="product-sort-container"]');
  }

  async addItemsToCart(items = []) {
    for (const item of items) {
      const addButton = this.page.locator(
        `button[data-test="add-to-cart-${item}"]`
      );
      await addButton.click();
    }
  }

  async addFirstNItems(n) {
    const addButtons = this.page.locator("button:has-text('Add to cart')");
    for (let i = 0; i < n; i++) {
      await addButtons.nth(i).click();
    }
  }

  async sortBy(option) {
    // option: "az" | "za" | "lohi" | "hilo"
    await this.sortDropdown.selectOption(option);
  }

  async goToCart() {
    await this.cartLink.click();
  }
}
